#' Bayesian Factor Analysis
#' 
#' \tabular{ll}{
#' Package: \tab bfa.mod \cr
#' Type: \tab Package\cr
#' Version: \tab 0.4\cr
#' Date: \tab 2016-9-07\cr
#' License: \tab GPL-3\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' This is a modified version of the 'bfa' package that provides 
#' posterior-index based sampling and sampling from the conditional 
#' predictive distribution for 'copula' models. 
#' Main description: Provides model fitting for several 
#' Bayesian factor models including Gaussian,
#' ordinal probit, mixed and semiparametric Gaussian
#' copula factor models under a range of priors.
#' 
#' @name bfa.mod-package
#' @docType package
#' @import coda
#' @import Rcpp
#' @import tmg
#' @importFrom stats biplot cov ecdf factanal model.frame pnorm qnorm quantile rbeta rgamma rnorm runif sd var
#' @import RcppArmadillo
#' @title Bayesian Factor Analysis
#' @author Jared Murray \email{jsmurray@@stat.cmu.edu}
#' @keywords package
#' @useDynLib bfa.mod
# @references
# \url{url}

NULL